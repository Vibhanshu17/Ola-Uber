from django.db import models

# Create your models here.

class Artist(models.Model):
    id = models.CharField(max_length=50, primary_key=True)
    name = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    genres_and_tags = models.CharField(max_length=50000)
    popularity_lastfm = models.IntegerField()
    popularity_nirvana = models.IntegerField()

class Awards(models.Model):
    year = models.IntegerField
    category = models.CharField(max_length=50)
    artist = models.CharField(max_length=50)
    nominee = models.CharField(max_length=50)
    association = models.CharField(max_length=50)

class Chords(models.Model):
    name = models.CharField(max_length=50)
    barre = models.IntegerField()
    position = models.CharField(max_length=50)

class Composition(models.Model):
    artist = models.CharField(max_length=50)
    song = models.CharField(max_length=500)
    chords_and_lyrics = models.CharField(max_length=500000)
    chords = models.CharField(max_length=500000)
    lyrics = models.CharField(max_length=500000)
    tabs = models.CharField(max_length=500000)
    language = models.CharField(max_length=50)
    tags = models.CharField(max_length=50000)
    chordlist = models.CharField(max_length=50000)

class Songs(models.Model):
    id = models.CharField(max_length=50, primary_key=True)
    name = models.CharField(max_length=500)
    artist_names = models.CharField(max_length=500)
    popularity = models.IntegerField()
    explicit = models.BooleanField(default=False)
    song_type = models.CharField(max_length=50)
    track_number = models.IntegerField()
    num_artists = models.IntegerField()
    num_available_markets = models.IntegerField()
    release_date = models.CharField(max_length=50)
    duration_ms = models.IntegerField()
    key = models.CharField(max_length=50)
    mode = models.CharField(max_length=50)
    time_signature = models.CharField(max_length=50)
    acousticness = models.DecimalField(max_digits=20, decimal_places=10)
    danceability = models.DecimalField(max_digits=20, decimal_places=10)
    energy = models.DecimalField(max_digits=20, decimal_places=10)
    instrumentalness = models.DecimalField(max_digits=20, decimal_places=10)
    liveness = models.DecimalField(max_digits=20, decimal_places=10)
    loudness = models.DecimalField(max_digits=20, decimal_places=10)
    speechiness = models.DecimalField(max_digits=20, decimal_places=10)
    valence = models.DecimalField(max_digits=20, decimal_places=10)
    tempo = models.DecimalField(max_digits=20, decimal_places=10)
    popularity_nirvana = models.IntegerField()
