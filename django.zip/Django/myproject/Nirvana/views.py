from django.shortcuts import render,redirect
from django.db import connection
from django.urls import reverse
import psycopg2

# Create your views here.

def about(request):
	return render(request, 'about.html')

def contact(request):
	return render(request, 'contact.html')

def songOnly(request):
	return render(request, 'songOnly.html')

def artistOnly(request):
	return render(request, 'artistOnly.html')

def awards(request):
	return render(request, 'awards.html')

def genre(request):
	return render(request, 'genre.html')

def complexity(request):
	return render(request, 'complexity.html')

def mood(request):
	return render(request, 'mood.html')

def home(request):
    if request.method == 'POST':
        search_option = request.POST.get('search_option')
        search_option2 = request.POST.get('complexityOption')
        search_option3 = request.POST.get('moodOption')
        search_text = request.POST.get('search_text')
        search_text1 = request.POST.get('search_text1')
        search_text2 = request.POST.get('search_text2')
        
        if search_option == 'song' or search_option == 'album':
            query = 'SELECT artist, artist_names FROM (SELECT * FROM Composition WHERE song = %s) AS t1 LEFT JOIN (SELECT * FROM Songs WHERE name = %s) AS t2 ON E\'\\\'\'||t1.artist||E\'\\\'\' = ANY(t2.artist_names);'
            connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
            with connection.cursor() as cursor:
                cursor.execute(query, [search_text,search_text])
                rows = cursor.fetchall()
                res = []
                for row in rows:
                    res.append({'artist': row[0], 'artist_names': row[1]})

        elif search_option == 'artist':
            query = 'SELECT song FROM (SELECT * FROM Composition WHERE artist = %s) AS t1 LEFT JOIN (SELECT * FROM Songs WHERE %s = ANY(artist_names)) AS t2 ON t1.song = t2.name;'
            connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
            with connection.cursor() as cursor:
                cursor.execute(query, [search_text,search_text])
                rows = cursor.fetchall()
                cursor.execute('SELECT * FROM Artist WHERE name = %s', [search_text])
                rows2 = cursor.fetchall()
                country = rows2[0][2]
                genres_and_tags = rows2[0][3]
                popularity = rows2[0][4]
                popularity_nirvana = rows2[0][5]
                res = []
                for row in rows:
                    res.append({'song': row[0]})

        elif search_option == 'genre':
            connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
            with connection.cursor() as cursor:
                cursor.execute('SELECT name, genres_and_tags FROM Artist WHERE genres_and_tags LIKE \'%\'||\''+search_text+'\'||\'%\';')
                rows = cursor.fetchall()
                res = []
                for row in rows:
                    res.append({'artist': row[0], 'genres_and_tags': row[1]})

        elif search_option == 'award':
            query = 'SELECT t1.artist, song, year, association FROM (SELECT * FROM Awards WHERE category = %s) AS t1 JOIN Composition ON t1.nominee = Composition.song AND t1.artist = Composition.artist;'
            connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
            with connection.cursor() as cursor:
                cursor.execute(query, [search_text])
                rows = cursor.fetchall()
                res = []
                for row in rows:
                    res.append({'artist': row[0], 'work': row[1], 'year': row[2], 'association': row[3]})

        elif search_option == 'complexity':
            if search_option2 == 'easy':
                x = '0'
                y = '70'
                a = '0'
                b = '3'
                barre = '0'
            elif search_option2 == 'intermediate':
                x = '70'
                y = '120'
                a = '3'
                b = '5'
                barre = '1'
            else:
                x = '120'
                y = '500'
                a = '5'
                b = '50'
                barre = '1'
            query = 'select name from songs where tempo between '+x+' and '+y+' union select song from (select song, unnest(chordlist) as chordlist from composition where array_length(chordlist, 1) between '+a+' and '+b+') as t1 inner join (select * from chords where barre = '+barre+') as t2 on t1.chordlist like \'%\' || t2.name || \'%\';'
            connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
            with connection.cursor() as cursor:
                cursor.execute(query)
                rows = cursor.fetchall()
                res = []
                for row in rows:
                    res.append({'song': row[0]})

        elif search_option == 'mood':
            if search_option3 == 'fun':
                query = 'SELECT DISTINCT song, artist FROM (SELECT song, artist, unnest(chordlist) as chordlist FROM composition WHERE tags LIKE ANY(ARRAY[ \''+'%'+'club'+'%'+'\', \''+'%'+'samba'+'%'+'\', \''+'%'+'funk'+'%'+'\', \''+'%'+'house'+'%'+'\', \''+'%'+'disco'+'%'+'\' ])) as t1 INNER JOIN chords ON t1.chordlist LIKE \''+'%'+'\'|| chords.name || \''+'%'+'\';'
                connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    res = []
                    for row in rows:
                        res.append({'song': row[0], 'artist': row[1]})
            elif search_option3 == 'sad':
                query = 'SELECT DISTINCT song, artist FROM (SELECT song, artist, unnest(chordlist) as chordlist FROM composition WHERE tags LIKE ANY(ARRAY[ \''+'%'+'sad'+'%'+'\', \''+'%'+'blues'+'%'+'\', \''+'%'+'sentimental'+'%'+'\', \''+'%'+'slow'+'%'+'\', \''+'%'+'breakup'+'%'+'\' ])) as t1 INNER JOIN chords ON t1.chordlist LIKE \''+'%'+'\'|| chords.name || \''+'%'+'\';'
                connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    res = []
                    for row in rows:
                        res.append({'song': row[0], 'artist': row[1]})


        if request.POST.get('button_clicked'):
            # Perform another database query for the new page
            with connection.cursor() as cursor:
                cursor.execute('SELECT artist, song FROM Composition ORDER BY RANDOM() LIMIT 1;')
                data = cursor.fetchall()
                artist = data[0][0]
                song = data[0][1]
            return render(request, 'InspireMe.html', {'artist': artist, 'song': song})
        
        else:
            if search_option == 'artist':
                return render(request, 'artistOnly.html', {'results': res, 'country': country, 'genres_and_tags': genres_and_tags, 'popularity': popularity, 'popularity_nirvana': popularity_nirvana, 'search_option': search_option, 'search_text': search_text})
            
            elif search_option == 'song' or search_option == 'album':
                return render(request, 'songOnly.html', {'results': res, 'search_option': search_option, 'search_text': search_text})
            
            elif search_option == 'award':
                return render(request, 'awards.html', {'results': res, 'search_option': search_option, 'search_text': search_text})
            
            elif search_option == 'genre':
                return render(request, 'genre.html', {'results': res, 'search_option': search_option, 'search_text': search_text})
            
            elif search_option == 'artist_song':
                return redirect('chords', artist = search_text1, song = search_text2)
            
            elif search_option == 'complexity':
                return render(request, 'complexity.html', {'results': res, 'search_option': search_option, 'search_text': search_option2})
            
            elif search_option == 'mood':
                return render(request, 'mood.html', {'results': res, 'search_option': search_option, 'search_text': search_option3})
    
    else:
        connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
        with connection.cursor() as cursor:
            cursor.execute("SELECT name, popularity_lastfm FROM Artist WHERE popularity_lastfm IS NOT NULL ORDER BY popularity_lastfm DESC LIMIT 5;")
            rows1 = cursor.fetchall()
            cursor.execute("SELECT name, artist_names, popularity FROM Songs WHERE popularity IS NOT NULL ORDER BY popularity DESC LIMIT 5;")
            rows2 = cursor.fetchall()
            cursor.execute("SELECT name, popularity_nirvana FROM Artist WHERE popularity_nirvana IS NOT NULL ORDER BY popularity_nirvana DESC LIMIT 5;")
            rows3 = cursor.fetchall()
            cursor.execute("SELECT song, artist, popularity_nirvana FROM Composition WHERE popularity_nirvana IS NOT NULL ORDER BY popularity_nirvana DESC LIMIT 5;")
            rows4 = cursor.fetchall()
        return render(request, 'home.html', {'artists': rows1, 'songs': rows2, 'artists_nirvana': rows3, 'songs_nirvana': rows4})
    
def search_results(request):
    return render(request, 'search_results.html')

# def chords(request, search_option, search_text, results):
#     return render(request, 'search_results.html')

def InspireMe(request):
    return render(request, 'InspireMe.html')

def chords(request, artist, song):
    connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
    with connection.cursor() as cursor:
        cursor.execute('SELECT * FROM (SELECT * FROM (SELECT * FROM Composition WHERE artist = %s AND song = %s) AS t1 LEFT JOIN (SELECT * FROM Songs WHERE name = %s AND E\'\\\'\'||%s||E\'\\\'\' = ANY(artist_names)) AS t2 ON 1=1) AS t3 JOIN (SELECT * FROM Artist Where name = %s) AS t4 ON 1=1;', [artist,song,song,artist,artist])
        rows = cursor.fetchall()
        cursor.execute('UPDATE Artist SET popularity_nirvana = popularity_nirvana + 1 WHERE name = %s;', [artist])
        connection.commit()
        cursor.execute('UPDATE Songs SET popularity_nirvana = popularity_nirvana + 1 WHERE name = %s AND E\'\\\'\'||%s||E\'\\\'\' = ANY(artist_names);', [song,artist])
        connection.commit()
        cursor.execute('UPDATE Composition SET popularity_nirvana = popularity_nirvana + 1 WHERE song = %s AND artist = %s;', [song,artist])
        connection.commit()
        # artist = rows[0][0]
        # song = rows[0][1]
        chords_and_lyrics = rows[0][2]
        chords = rows[0][3]
        lyrics = rows[0][4]
        tabs = rows[0][5]
        language = rows[0][6]
        tags = rows[0][7]
        chordlist = rows[0][8]
        artist_names = rows[0][11]
        popularity = rows[0][12]
        explicit = rows[0][13]
        song_type = rows[0][14]
        track_number = rows[0][15]
        num_artists = rows[0][16]
        num_available_markets = rows[0][17]
        release_date = rows[0][18]
        duration_ms = rows[0][19]
        key = rows[0][20]
        mode = rows[0][21]
        time_signature = rows[0][22]
        acousticness = rows[0][23]
        danceability = rows[0][24]
        energy = rows[0][25]
        instrumentalness = rows[0][26]
        liveness = rows[0][27]
        loudness = rows[0][28]
        speechiness = rows[0][29]
        valence = rows[0][30]
        tempo = rows[0][31]
        popularity_nirvana = rows[0][32]    
    return render(request, 'chords.html', {'artist': artist, 'song': song, 'chords_and_lyrics': chords_and_lyrics, 'chords': chords, 'lyrics': lyrics, 'tabs': tabs, 'language': language, 'tags': tags, 'chordlist': chordlist, 'artist_names': artist_names, 'popularity': popularity, 'explicit': explicit, 'song_type': song_type, 'track_number': track_number, 'num_artists': num_artists, 'num_available_markets': num_available_markets, 'release_date': release_date, 'duration_ms': duration_ms, 'key': key, 'mode': mode, 'time_signature': time_signature, 'acousticness': acousticness, 'danceability': danceability, 'energy': energy, 'instrumentalness': instrumentalness, 'liveness': liveness, 'loudness': loudness, 'speechiness': speechiness, 'valence': valence, 'tempo': tempo, 'popularity_nirvana': popularity_nirvana})

def library(request):
    connection = psycopg2.connect(database="projectcol362", user="group_47", password="1234", host="localhost", port="5433")
    with connection.cursor() as cursor:
        cursor.execute('SELECT * FROM Chords;')
        rows = cursor.fetchall()
        res = []
        for row in rows:
            res.append({'name': row[0], 'barre': row[1], 'position': row[2]})
    return render(request, 'library.html', {'results': res})
