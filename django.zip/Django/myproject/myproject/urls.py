"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from Nirvana.views import about
from Nirvana.views import contact
from Nirvana.views import songOnly
from Nirvana.views import artistOnly
from Nirvana.views import awards
from Nirvana.views import genre
from Nirvana.views import complexity
from Nirvana.views import mood
from Nirvana.views import home
from Nirvana.views import search_results
from Nirvana.views import InspireMe
from Nirvana.views import chords
from Nirvana.views import library
# from Nirvana.views import chords

urlpatterns = [
    path('admin/', admin.site.urls),
    path('song/<str:song>', songOnly, name='songOnly'),
    path('artist/<str:artist>/', artistOnly, name='artistOnly'),
    path('awards/<str:awards>/', awards, name='awards'),
    path('genre/<str:genre>/', genre, name='genre'),
    path('complexity/<str:complexity>/', complexity, name='complexity'),
    path('mood/<str:mod>/', mood, name='mood'),
    path('home/', home, name='home'),
    path('about/', about, name='about'),
    path('contact/', contact, name='contact'),
    path('search_results/', search_results, name='search_results'),
    # path('chords/', chords, name='chords'),
    path('InspireMe/', InspireMe, name='InspireMe'),
    # path("chords/," chords, name='chords'),
    path('chords/<str:artist>/<str:song>/', chords, name='chords'),
    path('library/', library, name='library'),
]
